la funcionalidad de login de usuarios no está completa (sessions)
no se vincula los carritos individuales por cada user 
falta algo de frontend para mejor entendimiento de rutas y visual (href)

alba
