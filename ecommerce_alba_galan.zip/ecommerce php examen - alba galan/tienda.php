<?php

include_once("com/cart/cart.php");
include_once("com/user/users.php");
include_once("com/catalog/catalog.php");


echo "<h1>tienda principal</h1>";

echo '<a href="catalogo.php">Ir al catalogo</a>';
