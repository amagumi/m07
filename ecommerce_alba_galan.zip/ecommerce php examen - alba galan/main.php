<?php

include_once("com/cart/cart.php");
include_once("com/user/users.php");
include_once("com/catalog/catalog.php");



echo '<a href="tienda.php">Ir a la tienda</a>';

// addToCart(10, 4);

// removeFromCart(5);

// updateCart(12, 10);

// userRegister(3, 'asier', 'chile', '123');

// getCatalog();

// productRegister(12, 'apio', 240, 0.15);

// productExists(4, 20);

// viewCart();
